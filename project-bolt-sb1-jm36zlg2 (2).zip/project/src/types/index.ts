export type UserRole = 'waiter' | 'admin';

export interface User {
  id: string;
  email: string;
  role: UserRole;
  name: string;
  createdAt: string;
}

export type OrderStatus = 'in-progress' | 'completed' | 'updated';

export interface OrderItem {
  name: string;
  quantity: number;
  price: number;
}

export interface Order {
  id: string;
  displayId: number; // Sequential display ID (1, 2, 3, etc.)
  tableNumber: string;
  items: OrderItem[];
  status: OrderStatus;
  notes?: string;
  timestamp: string;
  createdBy: string;
  basePrice: number;
  serviceFeePrice: number;
}

export interface MenuItem {
  id: string;
  name: string;
  grams?: string;
  price: number;
  category: string;
  is_available?: boolean;
  created_at?: string;
  updated_at?: string;
}

export interface AuthContextType {
  user: User | null;
  login: (email: string, password: string, role: UserRole) => Promise<boolean>;
  logout: () => void;
  isLoading: boolean;
}

export interface ThemeContextType {
  theme: 'light' | 'dark';
  toggleTheme: () => void;
}