import React from 'react';
import { AppRouter } from './components/routing/AppRouter';

function App() {
  return <AppRouter />;
}

export default App;