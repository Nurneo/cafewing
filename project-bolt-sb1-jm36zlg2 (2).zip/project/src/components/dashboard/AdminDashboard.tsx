import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Order, User } from '../../types';
import { OrderTable } from '../orders/OrderTable';
import { NewOrderPage } from '../orders/NewOrderPage';
import { MenuManagement } from '../admin/MenuManagement';
import { OrderManagement } from '../admin/OrderManagement';
import { Button } from '../ui/Button';
import { Plus, Download, BarChart3, List, Menu, Settings, TrendingUp, AlertCircle, Filter, Calendar, ChevronLeft, ChevronRight, Clock, DollarSign, Users } from 'lucide-react';
import { supabaseService } from '../../services/supabaseService';
import { useAuth } from '../../context/AuthContext';
import { StatsSkeleton } from '../ui/LoadingSkeleton';

export const AdminDashboard: React.FC = () => {
  const { t } = useTranslation();
  const { user } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [filteredOrders, setFilteredOrders] = useState<Order[]>([]);
  const [statusFilters, setStatusFilters] = useState<Record<Order['status'], boolean>>({
    'in-progress': true,
    'completed': true,
    'updated': true
  });
  const [users, setUsers] = useState<User[]>([]);
  const [activeTab, setActiveTab] = useState<'orders' | 'users' | 'analytics' | 'menu' | 'order-management'>('orders');
  const [currentView, setCurrentView] = useState<'dashboard' | 'new-order'>('dashboard');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Date analytics state
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [currentWeek, setCurrentWeek] = useState<Date>(new Date());
  const [showFullCalendar, setShowFullCalendar] = useState(false);
  const [dateFilteredOrders, setDateFilteredOrders] = useState<Order[]>([]);

  useEffect(() => {
    loadData();
    
    // Subscribe to real-time updates
    const unsubscribe = supabaseService.subscribeToOrders((updatedOrders) => {
      setOrders(updatedOrders);
    });

    return unsubscribe;
  }, []);

  useEffect(() => {
    // Filter orders based on status filters
    const filtered = orders.filter(order => statusFilters[order.status]);
    setFilteredOrders(filtered);
  }, [orders, statusFilters]);

  useEffect(() => {
    // Filter orders by selected date for analytics
    const dateStr = selectedDate.toDateString();
    const filtered = orders.filter(order => {
      const orderDate = new Date(order.timestamp).toDateString();
      return orderDate === dateStr;
    });
    setDateFilteredOrders(filtered);
  }, [selectedDate, orders]);

  const toggleStatusFilter = (status: Order['status']) => {
    setStatusFilters(prev => ({
      ...prev,
      [status]: !prev[status]
    }));
  };

  const getActiveFiltersCount = () => {
    return Object.values(statusFilters).filter(Boolean).length;
  };

  const loadData = async () => {
    try {
      setIsLoading(true);
      setError(null);
      
      const [ordersData] = await Promise.all([
        supabaseService.getOrders(),
      ]);
      
      setOrders(ordersData);
    } catch (error) {
      console.error('Error loading data:', error);
      setError(t('errors.loadingError'));
    } finally {
      setIsLoading(false);
    }
  };

  const handleCreateOrder = async (orderData: {
    tableNumber: string;
    items: Order['items'];
    status: Order['status'];
    notes?: string;
    basePrice: number;
    serviceFeePrice: number;
  }) => {
    try {
      if (!user?.id) {
        console.error('No user ID available');
        alert('User authentication error. Please try logging in again.');
        return;
      }

      const { error } = await supabaseService.createOrder({
        ...orderData,
        waiterId: user.id
      });
      
      if (error) {
        console.error('Error creating order:', error);
        alert(t('errors.savingError'));
        return;
      }

      setCurrentView('dashboard');
      // Orders will be updated via real-time subscription
    } catch (error) {
      console.error('Error creating order:', error);
      alert(t('errors.savingError'));
    }
  };

  const handleEditOrder = (order: Order) => {
    console.log('Admin dashboard - switching to order management tab for editing order:', order.id);
    // Switch to order management tab and pass the order to edit
    setActiveTab('order-management');
  };

  const handleDeleteOrder = async (orderId: string) => {
    if (confirm(t('orders.confirmDelete'))) {
      try {
        const { error } = await supabaseService.deleteOrder(orderId);
        
        if (error) {
          console.error('Error deleting order:', error);
          
          // Check for specific order not found error
          if (error.code === 'ORDER_NOT_FOUND') {
            alert(t('errors.orderNotFound'));
          } else {
            alert(t('errors.savingError'));
          }
          return;
        }
        
        // Orders will be updated via real-time subscription
      } catch (error) {
        console.error('Error deleting order:', error);
        alert(t('errors.savingError'));
      }
    }
  };

  const handleStatusChange = async (orderId: string, status: Order['status']) => {
    try {
      console.log('Admin attempting to change order status:', { orderId, status });
      
      const { error } = await supabaseService.updateOrder(orderId, { status });
      
      if (error) {
        console.error('Error updating order status:', error);
        
        // Check for specific order not found error
        if (error.code === 'ORDER_NOT_FOUND') {
          alert(t('errors.orderNotFound'));
          // Refresh orders to sync with server state
          loadData();
          // Throw error to propagate failure to calling function
          throw new Error('Order not found');
        } else {
          alert(t('errors.savingError'));
          // Throw error to propagate failure to calling function
          throw new Error('Failed to update order status');
        }
      }
      
      console.log('Order status updated successfully by admin');
      // Orders will be updated via real-time subscription
    } catch (error) {
      console.error('Error updating order status:', error);
      // Re-throw the error to propagate it to the calling function
      throw error;
    }
  };

  const handleUpdateOrder = async (updatedOrder: Order) => {
    try {
      const { error } = await supabaseService.updateOrder(updatedOrder.id, {
        tableNumber: updatedOrder.tableNumber,
        status: 'updated',
        notes: updatedOrder.notes,
        basePrice: updatedOrder.basePrice,
        serviceFeePrice: updatedOrder.serviceFeePrice,
        items: updatedOrder.items,
      });
      
      if (error) {
        console.error('Error updating order:', error);
        
        // Check for specific order not found error
        if (error.code === 'ORDER_NOT_FOUND') {
          alert(t('errors.orderNotFound'));
          // Refresh orders to sync with server state
          loadData();
        } else {
          alert(t('errors.savingError'));
        }
        return;
      }
      
      // Orders will be updated via real-time subscription
    } catch (error) {
      console.error('Error updating order:', error);
      alert(t('errors.savingError'));
    }
  };

  const handleCancelOrder = async (orderId: string) => {
    if (confirm(t('orders.confirmDelete'))) {
      try {
        const { error } = await supabaseService.deleteOrder(orderId);
        
        if (error) {
          console.error('Error canceling order:', error);
          
          // Check for specific order not found error
          if (error.code === 'ORDER_NOT_FOUND') {
            alert(t('errors.orderNotFound'));
          } else {
            alert(t('errors.savingError'));
          }
          return;
        }
        
        // Orders will be updated via real-time subscription
      } catch (error) {
        console.error('Error canceling order:', error);
        alert(t('errors.savingError'));
      }
    }
  };

  const handleExportOrders = () => {
    try {
      const csvContent = exportOrdersAsCSV(filteredOrders); // Export filtered orders
      const filename = `themis-orders-${new Date().toISOString().split('T')[0]}.csv`;
      downloadCSV(csvContent, filename);
    } catch (error) {
      console.error('Error exporting orders:', error);
      alert(t('errors.savingError'));
    }
  };

  const exportOrdersAsCSV = (orders: Order[]): string => {
    const headers = [t('orders.orderID'), t('orders.tableNumber'), t('orders.items'), t('orders.status'), t('orders.notes'), t('orders.basePrice'), t('orders.serviceFee'), t('orders.createdAt'), t('orders.createdBy')];
    const csvContent = [
      headers.join(','),
      ...orders.map((order, index) => [
        index + 1,
        order.tableNumber,
        `"${order.items.map(item => `${item.name} x${item.quantity}`).join('; ').replace(/"/g, '""')}"`,
        order.status,
        `"${(order.notes || '').replace(/"/g, '""')}"`,
        order.basePrice,
        order.serviceFeePrice,
        order.timestamp,
        order.createdBy
      ].join(','))
    ].join('\n');
    
    return csvContent;
  };

  const downloadCSV = (csvContent: string, filename: string): void => {
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
  };

  const getOrderStats = () => {
    const inProgress = orders.filter(o => o.status === 'in-progress').length;
    const completed = orders.filter(o => o.status === 'completed').length;
    const updated = orders.filter(o => o.status === 'updated').length;
    const totalRevenue = orders.reduce((sum, order) => sum + order.serviceFeePrice, 0);
    return { inProgress, completed, updated, total: orders.length, totalRevenue };
  };

  // Date analytics functions
  const getWeekDates = (date: Date) => {
    const week = [];
    const startOfWeek = new Date(date);
    const day = startOfWeek.getDay();
    const diff = startOfWeek.getDate() - day; // Adjust to get Sunday as start
    startOfWeek.setDate(diff);

    for (let i = 0; i < 7; i++) {
      const current = new Date(startOfWeek);
      current.setDate(startOfWeek.getDate() + i);
      week.push(current);
    }
    return week;
  };

  const getOrderCountForDate = (date: Date) => {
    const dateStr = date.toDateString();
    return orders.filter(order => {
      const orderDate = new Date(order.timestamp).toDateString();
      return orderDate === dateStr;
    }).length;
  };

  const isToday = (date: Date) => {
    return date.toDateString() === new Date().toDateString();
  };

  const isSameDate = (date1: Date, date2: Date) => {
    return date1.toDateString() === date2.toDateString();
  };

  const navigateWeek = (direction: 'prev' | 'next') => {
    setCurrentWeek(prev => {
      const newWeek = new Date(prev);
      newWeek.setDate(prev.getDate() + (direction === 'next' ? 7 : -7));
      return newWeek;
    });
  };

  const selectDate = (date: Date) => {
    setSelectedDate(date);
  };

  const goToToday = () => {
    const today = new Date();
    setSelectedDate(today);
    setCurrentWeek(today);
  };

  const getDateStats = () => {
    const inProgress = dateFilteredOrders.filter(o => o.status === 'in-progress').length;
    const completed = dateFilteredOrders.filter(o => o.status === 'completed').length;
    const updated = dateFilteredOrders.filter(o => o.status === 'updated').length;
    const totalRevenue = dateFilteredOrders.reduce((sum, order) => sum + order.serviceFeePrice, 0);
    const avgOrderValue = dateFilteredOrders.length > 0 ? totalRevenue / dateFilteredOrders.length : 0;
    const uniqueWaiters = new Set(dateFilteredOrders.map(o => o.createdBy)).size;

    return {
      total: dateFilteredOrders.length,
      inProgress,
      completed,
      updated,
      totalRevenue,
      avgOrderValue,
      uniqueWaiters
    };
  };

  const renderFullCalendar = () => {
    const today = new Date();
    const currentMonth = selectedDate;
    const daysInMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 0).getDate();
    const firstDay = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), 1).getDay();
    const days = [];
    const dayNames = ['SU', 'MO', 'TU', 'WE', 'TH', 'FR', 'SA'];

    // Add day headers
    const dayHeaders = dayNames.map(day => (
      <div key={day} className="text-center text-xs font-semibold text-gray-400 p-2">
        {day}
      </div>
    ));

    // Add empty cells for days before the first day of the month
    for (let i = 0; i < firstDay; i++) {
      days.push(<div key={`empty-${i}`} className="p-2"></div>);
    }

    // Add days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      const date = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), day);
      const orderCount = getOrderCountForDate(date);
      const isSelected = isSameDate(date, selectedDate);
      const isTodayDate = isToday(date);
      const isFutureDate = date > today;

      days.push(
        <button
          key={day}
          onClick={() => {
            if (!isFutureDate) {
              selectDate(date);
              setShowFullCalendar(false);
            }
          }}
          disabled={isFutureDate}
          className={`
            relative p-2 text-sm font-medium rounded-lg transition-all duration-200 hover:scale-105 min-h-[40px] flex flex-col items-center justify-center
            ${isSelected
              ? 'bg-cyan-500 text-black shadow-neon scale-105'
              : isTodayDate
              ? 'bg-blue-500/20 text-blue-400 border border-blue-500'
              : isFutureDate
              ? 'text-gray-600 cursor-not-allowed'
              : orderCount > 0
              ? 'text-white hover:bg-gray-700 border border-gray-600'
              : 'text-gray-400 hover:bg-gray-800'
            }
          `}
        >
          <span className="text-xs">{day}</span>
          {orderCount > 0 && !isSelected && (
            <div className={`
              absolute -top-1 -right-1 w-4 h-4 rounded-full text-xs flex items-center justify-center font-bold
              ${isTodayDate ? 'bg-blue-400 text-black' : 'bg-cyan-400 text-black'}
            `}>
              {orderCount > 9 ? '9+' : orderCount}
            </div>
          )}
        </button>
      );
    }

    return (
      <div className="absolute top-full left-0 mt-2 bg-gray-800 border border-gray-700 rounded-lg p-4 shadow-xl z-50 min-w-[300px]">
        {/* Calendar Header */}
        <div className="flex items-center justify-between mb-4">
          <button
            onClick={() => {
              const newDate = new Date(selectedDate);
              newDate.setMonth(newDate.getMonth() - 1);
              setSelectedDate(newDate);
            }}
            className="p-2 hover:bg-gray-700 rounded-lg transition-colors"
          >
            <ChevronLeft size={16} className="text-gray-400" />
          </button>
          <h3 className="text-lg font-semibold text-white">
            {selectedDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
          </h3>
          <button
            onClick={() => {
              const newDate = new Date(selectedDate);
              newDate.setMonth(newDate.getMonth() + 1);
              setSelectedDate(newDate);
            }}
            className="p-2 hover:bg-gray-700 rounded-lg transition-colors"
          >
            <ChevronRight size={16} className="text-gray-400" />
          </button>
        </div>

        {/* Calendar Grid */}
        <div className="grid grid-cols-7 gap-1 mb-4">
          {dayHeaders}
          {days}
        </div>

        {/* Quick Actions */}
        <div className="flex flex-wrap gap-2 pt-4 border-t border-gray-700">
          <Button
            variant="OUTLINE"
            size="sm"
            onClick={() => {
              goToToday();
              setShowFullCalendar(false);
            }}
            className="text-xs"
          >
            Today
          </Button>
        </div>
      </div>
    );
  };

  if (currentView === 'new-order') {
    return (
      <div className="page-transition">
        <NewOrderPage
          onBack={() => setCurrentView('dashboard')}
          onSubmit={handleCreateOrder}
        />
      </div>
    );
  }

  const stats = getOrderStats();
  const dateStats = getDateStats();
  const weekDates = getWeekDates(currentWeek);

  if (error) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-center fade-in px-4">
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <div className="text-red-400 text-lg font-medium mb-4">{error}</div>
          <Button variant="PRIMARY" onClick={loadData} className="min-h-[44px]">
            {t('common.tryAgain')}
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black page-transition">
      <div className="p-4 sm:p-6 max-w-7xl mx-auto">
        {/* Header with Administrator label */}
        <div className="flex flex-col space-y-4 sm:flex-row sm:justify-between sm:items-start sm:space-y-0 mb-6">
          <div className="slide-in-left">
            <div className="flex items-center space-x-3 mb-2">
              <h1 className="text-xl sm:text-2xl font-bold text-white text-heading">{t('dashboard.adminDashboard')}</h1>
              <span className="text-sm accent-cyan bg-cyan-900/30 px-3 py-1 rounded-full border border-cyan-700/50">Admin</span>
            </div>
            <p className="text-gray-300 text-sm sm:text-base text-subheading">
              {t('dashboard.welcome')}, <span className="accent-cyan font-semibold">{user?.name}</span>! {t('dashboard.manageOrders')}.
            </p>
          </div>
          
          <div className="flex flex-col space-y-2 sm:flex-row sm:space-y-0 sm:space-x-3 slide-in-right">
            <Button
              variant="SUCCESS"
              onClick={handleExportOrders}
              className="flex items-center justify-center space-x-2 min-h-[44px]"
            >
              <Download size={16} />
              <span>{t('dashboard.exportCSV')}</span>
            </Button>
            <Button
              variant="PRIMARY"
              onClick={() => setCurrentView('new-order')}
              className="flex items-center justify-center space-x-2 min-h-[44px]"
            >
              <Plus size={16} />
              <span>{t('orders.newOrder')}</span>
            </Button>
          </div>
        </div>

        {/* Navigation Tabs - Mobile Optimized */}
        <div className="flex flex-col sm:flex-row gap-2 mb-6 bg-gray-900 border border-gray-800 rounded-xl p-2 slide-up">
          {[
            { id: 'orders', label: t('dashboard.orders'), icon: List },
            { id: 'order-management', label: t('dashboard.manageOrdersTab'), icon: Settings },
            { id: 'menu', label: t('dashboard.menuTab'), icon: Menu },
            { id: 'analytics', label: t('dashboard.analyticsTab'), icon: BarChart3 }
          ].map(({ id, label, icon: Icon }, index) => (
            <button
              key={id}
              onClick={() => setActiveTab(id as any)}
              className={`flex items-center justify-center space-x-2 px-3 py-3 rounded-lg transition-all duration-200 font-semibold gpu-accelerated fade-in min-w-[120px] min-h-[44px] ${
                activeTab === id
                  ? 'bg-cyan-600 text-black shadow-neon scale-105'
                  : 'text-gray-400 hover:text-white hover:bg-gray-800 hover:scale-105'
              }`}
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <Icon size={16} />
              <span className="text-xs sm:text-sm">{label}</span>
            </button>
          ))}
        </div>

        {/* Content */}
        {activeTab === 'orders' && (
          <div className="fade-in">
            {/* Order Filter Section */}
            <div className="mb-6 slide-up">
              <div className="card-modern p-4">
                <div className="flex items-center space-x-4 mb-4">
                  <Filter size={18} className="text-gray-400" />
                  <h3 className="text-sm font-semibold text-white text-subheading">{t('orders.filterByStatus')}</h3>
                  <span className="text-xs text-gray-400 text-caption">
                    ({getActiveFiltersCount()}/3 {t('orders.statusesShown')})
                  </span>
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {(Object.keys(statusFilters) as Order['status'][]).map((status) => (
                    <button
                      key={status}
                      onClick={() => toggleStatusFilter(status)}
                      className={`
                        flex items-center justify-between p-3 rounded-lg border-2 transition-all duration-200 hover:scale-105 gpu-accelerated
                        ${statusFilters[status]
                          ? 'border-cyan-400 bg-cyan-400/10 shadow-neon'
                          : 'border-red-400 bg-red-400/10 shadow-lg'
                        }
                      `}
                    >
                      <div className="flex items-center space-x-3">
                        <div className={`
                          w-6 h-6 rounded-full flex items-center justify-center transition-all duration-200
                          ${statusFilters[status]
                            ? 'bg-cyan-400 text-black'
                            : 'bg-red-400 text-white'
                          }
                        `}>
                          {statusFilters[status] ? (
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                            </svg>
                          ) : (
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M6 18L18 6M6 6l12 12" />
                            </svg>
                          )}
                        </div>
                        <span className={`text-sm font-medium ${
                          statusFilters[status] ? 'text-cyan-400' : 'text-red-400'
                        } text-subheading`}>
                          {t(`orders.${status}`)}
                        </span>
                      </div>
                      
                      <div className={`text-xs px-2 py-1 rounded-full ${
                        statusFilters[status] 
                          ? 'bg-cyan-900/30 text-cyan-300' 
                          : 'bg-red-900/30 text-red-300'
                      } text-caption`}>
                        {orders.filter(order => order.status === status).length}
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Filter Summary */}
            <div className="mb-6 text-center">
              <div className="text-sm text-gray-400 text-caption">
                {t('orders.showingOrders')} <span className="font-semibold text-white mx-1">{filteredOrders.length}</span> {t('orders.ofOrders')} <span className="font-semibold text-white mx-1">{orders.length}</span> {t('orders.ordersText')}
              </div>
            </div>

            <OrderTable
              orders={filteredOrders}
              onEdit={handleEditOrder}
              onDelete={handleDeleteOrder}
              onStatusChange={handleStatusChange}
              isLoading={isLoading}
            />
          </div>
        )}

        {activeTab === 'order-management' && (
          <div className="fade-in">
            <OrderManagement
              orders={orders}
              onUpdateOrder={handleUpdateOrder}
              onCancelOrder={handleCancelOrder}
            />
          </div>
        )}

        {activeTab === 'menu' && (
          <div className="fade-in">
            <MenuManagement />
          </div>
        )}

        {activeTab === 'analytics' && (
          <div className="slide-up">
            {isLoading ? (
              <StatsSkeleton />
            ) : (
              <div className="space-y-8">
                {/* Date Selection - Week View */}
                <div className="card-modern p-6">
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0 mb-6">
                    <div>
                      <h3 className="text-lg font-bold text-white mb-2 text-heading">Select a date</h3>
                      <p className="text-gray-400 text-subheading">View analytics for a specific date</p>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      <span className="text-gray-400 text-sm">
                        {selectedDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
                      </span>
                      <div className="relative">
                        <button
                          onClick={() => setShowFullCalendar(!showFullCalendar)}
                          className="p-2 bg-gray-800 border border-gray-600 rounded-lg text-cyan-400 hover:bg-gray-700 transition-all duration-200"
                          title="Open full calendar"
                        >
                          <Calendar size={18} />
                        </button>
                        
                        {showFullCalendar && renderFullCalendar()}
                      </div>
                    </div>
                  </div>

                  {/* Week Navigation */}
                  <div className="flex items-center justify-between mb-4">
                    <button
                      onClick={() => navigateWeek('prev')}
                      className="p-2 hover:bg-gray-700 rounded-lg transition-colors"
                    >
                      <ChevronLeft size={16} className="text-gray-400" />
                    </button>
                    
                    <div className="flex items-center space-x-2">
                      <Button
                        variant="OUTLINE"
                        size="sm"
                        onClick={goToToday}
                        className="text-xs"
                      >
                        Today
                      </Button>
                    </div>
                    
                    <button
                      onClick={() => navigateWeek('next')}
                      className="p-2 hover:bg-gray-700 rounded-lg transition-colors"
                    >
                      <ChevronRight size={16} className="text-gray-400" />
                    </button>
                  </div>

                  {/* Week View */}
                  <div className="grid grid-cols-7 gap-2">
                    {['MO', 'TU', 'WE', 'TH', 'FR', 'SA', 'SU'].map((day, index) => {
                      const date = weekDates[index === 6 ? 0 : index + 1]; // Adjust for Sunday/Monday start
                      const orderCount = getOrderCountForDate(date);
                      const isSelected = isSameDate(date, selectedDate);
                      const isTodayDate = isToday(date);
                      const isFutureDate = date > new Date();
                      
                      return (
                        <div key={day} className="text-center">
                          <div className="text-xs font-semibold text-gray-400 mb-2 p-1">
                            {day}
                          </div>
                          <button
                            onClick={() => !isFutureDate && selectDate(date)}
                            disabled={isFutureDate}
                            className={`
                              relative w-full p-3 rounded-2xl transition-all duration-200 hover:scale-105 gpu-accelerated
                              ${isSelected
                                ? 'bg-cyan-500 text-black shadow-neon scale-105'
                                : isTodayDate
                                ? 'bg-blue-500/20 text-blue-400 border-2 border-blue-500'
                                : isFutureDate
                                ? 'text-gray-600 cursor-not-allowed bg-gray-800'
                                : orderCount > 0
                                ? 'text-white hover:bg-gray-700 border border-gray-600 bg-gray-800'
                                : 'text-gray-400 hover:bg-gray-800 bg-gray-900'
                              }
                            `}
                          >
                            <div className="text-lg font-bold">
                              {date.getDate()}
                            </div>
                            {orderCount > 0 && !isSelected && (
                              <div className="absolute -top-1 -right-1 w-5 h-5 bg-cyan-400 text-black rounded-full text-xs flex items-center justify-center font-bold">
                                {orderCount > 9 ? '9+' : orderCount}
                              </div>
                            )}
                          </button>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Date-specific Analytics */}
                <div className="space-y-6">
                  <div className="text-center">
                    <h3 className="text-xl font-bold text-white mb-2 text-heading">
                      Analytics for {selectedDate.toLocaleDateString('en-US', { 
                        weekday: 'long',
                        month: 'long', 
                        day: 'numeric',
                        year: 'numeric'
                      })}
                    </h3>
                    <p className="text-gray-400 text-subheading">
                      {dateStats.total} orders • {dateStats.totalRevenue}с revenue
                    </p>
                  </div>

                  {/* Date Stats Grid */}
                  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
                    {[
                      { 
                        label: 'Total Orders', 
                        value: dateStats.total, 
                        icon: TrendingUp, 
                        color: 'accent-cyan',
                        description: 'Orders placed'
                      },
                      { 
                        label: 'In Progress', 
                        value: dateStats.inProgress, 
                        icon: Clock, 
                        color: 'accent-blue',
                        description: 'Currently active'
                      },
                      { 
                        label: 'Completed', 
                        value: dateStats.completed, 
                        icon: '✓', 
                        color: 'accent-green',
                        description: 'Successfully finished'
                      },
                      { 
                        label: 'Updated', 
                        value: dateStats.updated, 
                        icon: '↻', 
                        color: 'text-violet-400',
                        description: 'Modified orders'
                      },
                      { 
                        label: 'Revenue', 
                        value: `${dateStats.totalRevenue}с`, 
                        icon: DollarSign, 
                        color: 'accent-green',
                        description: 'Total earnings'
                      },
                      { 
                        label: 'Avg Order', 
                        value: `${Math.round(dateStats.avgOrderValue)}с`, 
                        icon: '📊', 
                        color: 'accent-cyan',
                        description: 'Average order value'
                      }
                    ].map(({ label, value, icon: Icon, color, description }, index) => (
                      <div 
                        key={label} 
                        className="card-modern p-4 text-center hover-lift fade-in"
                        style={{ animationDelay: `${index * 0.1}s` }}
                      >
                        <div className="flex items-center justify-center mb-3">
                          {typeof Icon === 'string' ? (
                            <span className="text-2xl">{Icon}</span>
                          ) : (
                            <Icon className={color} size={24} />
                          )}
                        </div>
                        <h3 className="text-xs font-semibold text-gray-400 mb-1 text-subheading">{label}</h3>
                        <p className={`text-2xl font-bold ${color} text-heading mb-1`}>{value}</p>
                        <p className="text-xs text-gray-500 text-caption">{description}</p>
                      </div>
                    ))}
                  </div>

                  {/* Orders for Selected Date */}
                  {dateFilteredOrders.length > 0 ? (
                    <div className="card-modern p-6">
                      <h3 className="text-lg font-bold text-white mb-4 text-heading">
                        Orders ({dateFilteredOrders.length})
                      </h3>
                      
                      <div className="space-y-3 max-h-96 overflow-y-auto scrollbar-modern">
                        {dateFilteredOrders.map((order, index) => (
                          <div 
                            key={order.id} 
                            className="bg-gray-800 border border-gray-700 rounded-lg p-4 hover:bg-gray-750 transition-colors fade-in"
                            style={{ animationDelay: `${index * 0.05}s` }}
                          >
                            <div className="flex items-center justify-between mb-2">
                              <div className="flex items-center space-x-3">
                                <span className="text-sm font-bold text-white">#{order.displayId}</span>
                                <span className="text-sm text-gray-300">{order.tableNumber}</span>
                                <span className={`px-2 py-1 rounded-full text-xs font-bold ${
                                  order.status === 'completed' ? 'bg-green-900 text-green-300' :
                                  order.status === 'in-progress' ? 'bg-blue-900 text-blue-300' :
                                  'bg-purple-900 text-purple-300'
                                }`}>
                                  {order.status.replace('-', ' ')}
                                </span>
                              </div>
                              <div className="text-right">
                                <div className="text-sm font-bold accent-cyan">{order.serviceFeePrice}с</div>
                                <div className="text-xs text-gray-400">
                                  {new Date(order.timestamp).toLocaleTimeString()}
                                </div>
                              </div>
                            </div>
                            
                            <div className="text-sm text-gray-400 mb-2">
                              {order.items.map(item => `${item.name} x${item.quantity}`).join(', ')}
                            </div>
                            
                            <div className="flex items-center justify-between text-xs text-gray-500">
                              <span>Waiter: {order.createdBy}</span>
                              {order.notes && <span>Notes: {order.notes}</span>}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <div className="card-modern p-12 text-center">
                      <Calendar className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                      <h3 className="text-lg font-semibold text-gray-400 mb-2 text-subheading">No Orders Found</h3>
                      <p className="text-gray-500 text-caption">
                        No orders were placed on this date
                      </p>
                    </div>
                  )}
                </div>

                {/* Overall Analytics */}
                <div className="card-modern p-6">
                  <h3 className="text-lg font-bold text-white mb-4 text-heading">Overall Statistics</h3>
                  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 sm:gap-6">
                    {[
                      { label: t('dashboard.totalOrders'), value: stats.total, icon: TrendingUp, color: 'accent-cyan' },
                      { label: t('dashboard.inProgress'), value: stats.inProgress, color: 'accent-blue', bg: 'bg-blue-500' },
                      { label: t('dashboard.updated'), value: stats.updated, color: 'text-violet-400', bg: 'bg-violet-500' },
                      { label: t('dashboard.completed'), value: stats.completed, color: 'accent-green', bg: 'bg-green-500' },
                      { label: t('dashboard.totalRevenue'), value: `${stats.totalRevenue}с`, icon: '💰', color: 'accent-green' }
                    ].map(({ label, value, icon: Icon, color, bg }, index) => (
                      <div 
                        key={label} 
                        className="card-secondary p-3 sm:p-6 text-center hover-lift fade-in"
                        style={{ animationDelay: `${index * 0.1}s` }}
                      >
                        <div className="flex items-center justify-center mb-2 sm:mb-3">
                          {typeof Icon === 'string' ? (
                            <span className="text-lg sm:text-2xl">{Icon}</span>
                          ) : Icon ? (
                            <Icon className={color} size={20} />
                          ) : (
                            <div className={`w-3 h-3 ${bg} rounded-full`}></div>
                          )}
                        </div>
                        <h3 className="text-xs sm:text-sm font-semibold text-gray-400 mb-1 sm:mb-2 text-subheading">{label}</h3>
                        <p className={`text-lg sm:text-3xl font-bold ${color} text-heading`}>{value}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Click outside to close calendar */}
        {showFullCalendar && (
          <div 
            className="fixed inset-0 z-40" 
            onClick={() => setShowFullCalendar(false)}
          />
        )}
      </div>
    </div>
  );
};