import React from 'react';
import { useTheme } from '../../context/ThemeContext';
import { Sun, Moon } from 'lucide-react';

export const ThemeToggle: React.FC = () => {
  const { theme, toggleTheme } = useTheme();

  return (
    <button
      onClick={toggleTheme}
      className="relative w-16 h-8 rounded-full transition-all duration-500 ease-in-out focus:outline-none focus:ring-2 focus:ring-accent-primary/50 focus:ring-offset-2 focus:ring-offset-bg-primary group"
      style={{
        background: theme === 'dark' 
          ? 'linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)'
          : 'linear-gradient(135deg, #87ceeb 0%, #98d8e8 50%, #b0e0e6 100%)',
        boxShadow: theme === 'dark'
          ? '0 4px 12px rgba(0, 255, 255, 0.2), inset 0 2px 4px rgba(255, 255, 255, 0.1)'
          : '0 4px 12px rgba(255, 215, 0, 0.3), inset 0 2px 4px rgba(255, 255, 255, 0.3)'
      }}
      aria-label={`Switch to ${theme === 'dark' ? 'light' : 'dark'} theme`}
    >
      {/* Background Stars/Clouds Effect */}
      <div className="absolute inset-0 rounded-full overflow-hidden">
        {theme === 'dark' ? (
          // Stars for dark theme
          <>
            <div className="absolute top-1 left-2 w-0.5 h-0.5 bg-white rounded-full opacity-60 animate-pulse"></div>
            <div className="absolute top-2 right-3 w-0.5 h-0.5 bg-white rounded-full opacity-40 animate-pulse" style={{ animationDelay: '0.5s' }}></div>
            <div className="absolute bottom-1.5 left-4 w-0.5 h-0.5 bg-white rounded-full opacity-80 animate-pulse" style={{ animationDelay: '1s' }}></div>
          </>
        ) : (
          // Clouds for light theme
          <>
            <div className="absolute top-1 left-1 w-2 h-1 bg-white/40 rounded-full"></div>
            <div className="absolute top-2 right-2 w-1.5 h-0.5 bg-white/30 rounded-full"></div>
            <div className="absolute bottom-1 left-3 w-1 h-0.5 bg-white/50 rounded-full"></div>
          </>
        )}
      </div>

      {/* Sliding Toggle */}
      <div
        className="absolute top-0.5 w-7 h-7 rounded-full transition-all duration-500 ease-in-out flex items-center justify-center shadow-lg transform"
        style={{
          left: theme === 'dark' ? '2px' : 'calc(100% - 30px)',
          background: theme === 'dark'
            ? 'linear-gradient(135deg, #e6e6fa 0%, #d8bfd8 50%, #dda0dd 100%)'
            : 'linear-gradient(135deg, #ffd700 0%, #ffed4e 50%, #fff59d 100%)',
          boxShadow: theme === 'dark'
            ? '0 2px 8px rgba(221, 160, 221, 0.4), 0 0 12px rgba(230, 230, 250, 0.3)'
            : '0 2px 8px rgba(255, 215, 0, 0.4), 0 0 12px rgba(255, 237, 78, 0.3)'
        }}
      >
        {theme === 'dark' ? (
          <Moon 
            size={14} 
            className="text-indigo-900 transition-all duration-300"
            style={{ filter: 'drop-shadow(0 0 2px rgba(75, 0, 130, 0.5))' }}
          />
        ) : (
          <Sun 
            size={14} 
            className="text-orange-800 transition-all duration-300 animate-spin"
            style={{ 
              filter: 'drop-shadow(0 0 2px rgba(255, 140, 0, 0.5))',
              animationDuration: '8s'
            }}
          />
        )}
      </div>

      {/* Glow Effect on Hover */}
      <div 
        className="absolute inset-0 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"
        style={{
          background: theme === 'dark'
            ? 'radial-gradient(circle, rgba(0, 255, 255, 0.1) 0%, transparent 70%)'
            : 'radial-gradient(circle, rgba(255, 215, 0, 0.2) 0%, transparent 70%)',
          boxShadow: theme === 'dark'
            ? '0 0 20px rgba(0, 255, 255, 0.3)'
            : '0 0 20px rgba(255, 215, 0, 0.4)'
        }}
      />

      {/* Ripple Effect */}
      <div className="absolute inset-0 rounded-full overflow-hidden">
        <div 
          className="absolute inset-0 rounded-full opacity-0 group-active:opacity-100 transition-opacity duration-150"
          style={{
            background: `radial-gradient(circle, ${theme === 'dark' ? 'rgba(0, 255, 255, 0.2)' : 'rgba(255, 215, 0, 0.3)'} 0%, transparent 70%)`
          }}
        />
      </div>
    </button>
  );
};